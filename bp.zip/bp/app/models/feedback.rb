class Feedback < ApplicationRecord
  belongs_to :book
end
